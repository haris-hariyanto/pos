// import '~admin-lte/dist/css/adminlte.min.css';
// import '~admin-lte/plugins/fontawesome-free/css/all.min.css';

// import '~admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js';
// import '~admin-lte/dist/js/adminlte.min.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();