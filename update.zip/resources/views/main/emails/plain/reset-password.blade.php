{{ $username }},

{{ __('To complete the phase of resetting your account password, you will need to go to the URL below.') }}

{{ $resetPasswordURL }}

{{ __('This password reset link will expire in 60 minutes.') }}

{{ __('Thank you') }},
{{ config('app.name') }}