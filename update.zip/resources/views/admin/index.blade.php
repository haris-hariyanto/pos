<x-admin.layouts.app>
    <x-slot:pageTitle>{{ __('Dashboard') }}</x-slot>
</x-admin.layouts.app>