<p>Welcome to {{ config('app.name') }}.</p>

<p>{{ config('app.name') }} is a database website. Here we will provide you only interesting content. We're dedicated to providing you the best content. We hope you enjoy our content as much as we enjoy offering them to you.</p>

<p>Thanks for visiting our website!</p>